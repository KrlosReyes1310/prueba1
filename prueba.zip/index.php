<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurante El Cañagüatero</title>
</head>
<body>
    <center><h1>Bienvenido al Restaurante El Cañagüatero</h1></center>
    <center><h2>*****MENU*****</h2></center>
    <center><H3>Tacos al pastor--------- Valor: $ 2000 pesos.</H3></center>
    <center><H3>Agua de jamaica--------- Valor: $ 6000 pesos</H3></center>

    <center> <nav>
        <ul>
            <li><h3><a href="crear_pedido.php">Solicitar Pedido</a></h3></li>
            <li><h3><a href="listar_pedidos.php">Listar Pedidos</a></h3></li>
        </ul>
        
    </nav>
    </center>
</body>
</html>